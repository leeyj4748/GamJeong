package com.cos.Baseballmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseballManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
