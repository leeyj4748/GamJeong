package com.cos.Baseballmanagement.web.dto.stadium;

import com.cos.Baseballmanagement.domain.stadium.Stadium;

import lombok.Data;

@Data
public class StadiumSaveReqDto {
	private String name;
	private String openingDate;
	private String location;
	
	public Stadium toEntity() {
		 return Stadium.builder()
		            .name(name)
		            .openingDate(openingDate)
		            .location(location)
		            .build();
}
}