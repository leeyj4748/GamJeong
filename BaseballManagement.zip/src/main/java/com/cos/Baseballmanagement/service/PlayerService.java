package com.cos.Baseballmanagement.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.qlrm.mapper.JpaResultMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cos.Baseballmanagement.domain.player.Player;
import com.cos.Baseballmanagement.domain.player.PlayerRepository;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class PlayerService {
	private final PlayerRepository playerRepository;
	private final EntityManager em;

	@Transactional
	public Player 선수등록(Player player) {
		return playerRepository.save(player);
	}

	@Transactional(readOnly = true)
	public List<Player> 선수리스트가져오기() {
		return playerRepository.findAll();
	}

	@Transactional
	public void 삭제하기(int id) {
		playerRepository.deleteById(id);
	}


}
